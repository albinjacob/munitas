import json
print(json.dumps({"document": "tx-batch", "priority": "medium", "reason": "3 transactions scored, 1 flagged for manual review"}))
