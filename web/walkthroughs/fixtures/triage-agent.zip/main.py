import json
print(json.dumps({"document": "radiology-intake-batch", "priority": "high", "reason": "contains an unusually urgent phrase, flagged for a human reviewer first"}))
