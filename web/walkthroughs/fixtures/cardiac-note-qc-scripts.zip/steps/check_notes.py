import json
print(json.dumps({"recommendation": "pass", "reason": "cardiac note fields present and well-formed"}))
